# Prompts para Artigo sobre Engenharia Elétrica

## Prompt para Conteúdo do Artigo (Texto)

Comporte-se como um escritor de artigos de tecnologia para jovens, explicando Engenharia Elétrica de forma super simples e divertida. Siga as regras abaixo:

{REGRAS}
> Use no máximo 5 linhas por bloco de explicação.
> Explique de maneira informal, como se estivesse conversando com uma criança curiosa de 10 anos.
> Crie o conteúdo para os seguintes blocos, mantendo a ordem:

*   **O que é Engenharia Elétrica?** (Uma introdução simples e cativante sobre o que faz um engenheiro eletricista e por que é legal)
*   **Superpoderes do Engenheiro Eletricista:** (Fale sobre as áreas principais como gerar energia (luz!), fazer a internet e o celular funcionarem (telecomunicações!) e criar aparelhos eletrônicos (como videogames!))
*   **Mágica no Dia a Dia:** (Dê exemplos de como a Engenharia Elétrica está escondida em coisas que usamos todos os dias, como acender a luz, usar o computador ou assistir TV)
*   **O Futuro Chegou!** (Comente sobre coisas novas e empolgantes, como carros elétricos, energia do sol e do vento (renováveis!) e casas inteligentes)
*   **Que tal virar um Mago da Eletricidade?** (Faça um CTA - Call to Action - convidando o leitor a pesquisar mais sobre o assunto ou cursos na área, se ele achou interessante)
*   **#Hashtags:** (Crie 3 hashtags legais e curtas sobre Engenharia Elétrica)

Lembre-se: linguagem super simples, divertida e direta ao ponto!

## Prompts para Imagens

1.  **Imagem de Capa:** Uma ilustração vibrante e colorida no estilo cartoon mostrando raios de energia, lâmpadas acesas, engrenagens e símbolos de tecnologia (como wi-fi e circuitos) se conectando de forma divertida e mágica. O fundo deve ser azul escuro com estrelas brilhantes. Aspecto: Paisagem (landscape).
2.  **Imagem Bloco 1 (O que é?):** Desenho animado de uma criança curiosa com olhos arregalados olhando para uma lâmpada acesa magicamente por fios conectados a uma pequena bateria. Estilo cartoon, cores vivas. Aspecto: Quadrado (square).
3.  **Imagem Bloco 2 (Superpoderes):** Ilustração estilo cartoon mostrando três 'superpoderes' da engenharia elétrica: uma mão segurando um raio (energia), outra mão segurando um celular com sinal de wi-fi (telecomunicações) e outra mão montando um pequeno robô (eletrônica). Fundo neutro. Aspecto: Quadrado (square).
4.  **Imagem Bloco 3 (Mágica no Dia a Dia):** Cena de uma sala de estar aconchegante em estilo cartoon, com uma TV ligada, um abajur aceso e um laptop aberto, com pequenas faíscas ou linhas de energia conectando os aparelhos de forma sutil e mágica. Aspecto: Quadrado (square).
5.  **Imagem Bloco 4 (Futuro):** Ilustração futurista em estilo cartoon mostrando um carro elétrico sendo carregado por energia solar vinda de painéis em um telhado, ao lado de uma turbina eólica pequena. Cores brilhantes e otimistas. Aspecto: Quadrado (square).
