# Ebook: Eletrônica Descomplicada: Seu Guia Rápido para Entender Circuitos!

Este repositório contém o material desenvolvido para o desafio da DIO "Criando um Ebook com ChatGPT e Ferramentas de IA".

O objetivo foi criar um ebook introdutório sobre eletrônica, com linguagem simples e visual atraente para iniciantes.

## 📖 Leia o Ebook

[Clique aqui para ler o ebook em PDF](./ebook_eletronica.pdf)

## 💻 Tecnologias e Ferramentas Utilizadas

*   **ChatGPT:** Utilizado para gerar o conteúdo textual do ebook com base em prompts específicos.
*   **IA de Geração de Imagens:** Utilizada para criar a capa e as ilustrações dos capítulos.
*   **WeasyPrint (Python):** Utilizado para converter o conteúdo HTML e CSS em um arquivo PDF formatado.

## 📄 Prompts Utilizados

Todos os prompts detalhados para a geração do conteúdo textual e das imagens podem ser encontrados no arquivo:
[prompts_ebook_eletronica.md](./prompts_ebook_eletronica.md)

## ✨ Conteúdo do Repositório

*   `ebook_eletronica.pdf`: O ebook finalizado em formato PDF.
*   `prompts_ebook_eletronica.md`: Arquivo contendo todos os prompts utilizados.
*   `images/`: Pasta com todas as imagens geradas para o ebook (capa e capítulos).
*   `README.md`: Este arquivo.

## 🛠️ Como Replicar

1.  Utilize os prompts do arquivo `prompts_ebook_eletronica.md` em ferramentas como ChatGPT (para texto) e geradores de imagem IA.
2.  Organize o texto e as imagens (salvas na pasta `images/`).
3.  (Opcional) Crie um arquivo HTML (`ebook_eletronica.html` - não incluído aqui) para estruturar o conteúdo.
4.  (Opcional) Utilize uma ferramenta como WeasyPrint para converter o HTML em PDF (`ebook_eletronica.pdf`). Alternativamente, use editores de texto/documentos para montar o ebook.

---

*Desenvolvido como parte do desafio da Digital Innovation One.*

