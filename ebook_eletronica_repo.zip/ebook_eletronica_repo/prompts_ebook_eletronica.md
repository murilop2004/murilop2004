# Prompts para Ebook sobre Eletrônica Descomplicada

## Prompt para Conteúdo do Ebook (Texto)

**Atue como:** Um autor de ebooks didáticos e super amigável, especialista em explicar conceitos complexos de forma simples e divertida para iniciantes absolutos em eletrônica.

**Título do Ebook:** Eletrônica Descomplicada: Seu Guia Rápido para Entender Circuitos!

**Objetivo:** Criar o conteúdo textual completo para um ebook introdutório sobre eletrônica, seguindo a estrutura de capítulos abaixo.

**Tom de Voz:** Extremamente simples, claro, encorajador e informal. Use analogias do dia a dia. Evite jargões técnicos ou explique-os de forma muito básica se inevitável. Imagine que está explicando para um amigo curioso que nunca viu eletrônica antes.

**Estrutura e Conteúdo por Capítulo:**

1.  **Introdução: Bem-vindo ao Mundo da Eletrônica!**
    *   O que é eletrônica de forma super simples (a "mágica" por trás dos aparelhos).
    *   Por que é legal e útil aprender o básico (despertar a curiosidade).
    *   O que o leitor vai descobrir neste guia rápido.

2.  **Capítulo 1: Os Tijolinhos da Eletrônica**
    *   Apresentar os componentes básicos como peças de um Lego.
    *   Explicar o que faz (de forma MUITO simples) um resistor, capacitor, LED e transistor. Use analogias (resistor = "diminuidor de velocidade", capacitor = "caixinha de energia rápida", LED = "luzinha", transistor = "porteiro elétrico").

3.  **Capítulo 2: Montando o Quebra-Cabeça (Circuitos!)**
    *   O que é um circuito (o caminho da eletricidade).
    *   Como os componentes se conectam para fazer algo acontecer.
    *   Exemplo super básico: como conectar uma pilha, um interruptor simples e um LED para acendê-lo.

4.  **Capítulo 3: Energia para Tudo Funcionar**
    *   De onde vem a "comida" dos circuitos (energia elétrica).
    *   Falar sobre pilhas, baterias e a energia da tomada (com cuidado!).
    *   A importância da voltagem correta (para não "queimar" as peças).

5.  **Capítulo 4: Hora de Experimentar (Com Segurança!)**
    *   Dicas para quem quer começar a brincar com eletrônica.
    *   Sugestão de kits para iniciantes (como os de Arduino ou similares, mencionando que existem kits prontos).
    *   Regra número 1: Segurança! Cuidados básicos ao mexer com eletricidade (mesmo a de pilhas).

6.  **Conclusão: A Aventura Só Começou!**
    *   Recapitulando o que foi aprendido de forma animadora.
    *   Incentivo para continuar explorando e aprendendo mais.
    *   Mensagem final positiva sobre o universo da eletrônica.

**Regras Adicionais:**
*   Parágrafos curtos e diretos.
*   Linguagem acessível e motivadora.
*   Foco total no iniciante.

## Prompts para Imagens do Ebook

**Estilo Geral:** Ilustrações em estilo cartoon/ícone, simples, coloridas e amigáveis. Foco na clareza visual.

1.  **Imagem de Capa:** Ilustração estilo cartoon de um robô simpático segurando um LED aceso e brilhante, cercado por símbolos simples de circuitos (linhas, resistores estilizados). Fundo claro e vibrante. Incluir espaço para o título "Eletrônica Descomplicada". **Aspecto:** Retrato (portrait).
2.  **Imagem Introdução:** Desenho animado mostrando diversos aparelhos eletrônicos comuns (smartphone, fone de ouvido, controle de videogame) com pequenas linhas de energia brilhantes conectando-os sutilmente. **Aspecto:** Quadrado (square).
3.  **Imagem Capítulo 1:** Quatro ícones/ilustrações simples e claras lado a lado, representando um resistor, um capacitor, um LED (aceso) e um transistor, cada um com seu nome abaixo. **Aspecto:** Paisagem (landscape) ou quatro quadrados (square) separados.
4.  **Imagem Capítulo 2:** Diagrama de circuito MUITO simples e visualmente claro, mostrando uma bateria, um interruptor (fechado), um resistor e um LED (aceso), com setas indicando o fluxo da corrente de forma intuitiva. **Aspecto:** Quadrado (square).
5.  **Imagem Capítulo 3:** Ilustração comparando três fontes de energia: uma pilha AA, uma bateria de celular (power bank) e uma tomada de parede com um plugue. Estilo cartoon amigável. **Aspecto:** Quadrado (square).
6.  **Imagem Capítulo 4:** Desenho de mãos (estilo cartoon) montando cuidadosamente componentes em uma protoboard (placa de ensaio), com algumas ferramentas simples ao lado (como um pequeno alicate). Foco na segurança e experimentação. **Aspecto:** Quadrado (square).
7.  **Imagem Conclusão:** Ilustração de uma porta se abrindo, revelando um caminho iluminado que leva a um horizonte com silhuetas de projetos eletrônicos e ideias (lâmpadas, robôs, etc.). Tom inspirador. **Aspecto:** Quadrado (square).
